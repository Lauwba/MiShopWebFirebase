<script src="https://www.gstatic.com/firebasejs/5.8.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyC-JibzzJZwR9Ai3qnkTWDHzl847lIUmg0",
    authDomain: "mishop.firebaseapp.com",
    databaseURL: "https://mishop.firebaseio.com",
    projectId: "mishop",
    storageBucket: "mishop.appspot.com",
    messagingSenderId: "155290684345"
  };
  firebase.initializeApp(config);
</script>
<!--<script src="https://www.gstatic.com/firebasejs/5.8.2/firebase.js"></script>
<script>
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyDnJf6n_5YbJ7ObrTWAd4vSd5DZ-djtC8E",
        authDomain: "fir-realtime-db-web-7bd70.firebaseapp.com",
        databaseURL: "https://fir-realtime-db-web-7bd70.firebaseio.com",
        projectId: "fir-realtime-db-web-7bd70",
        storageBucket: "fir-realtime-db-web-7bd70.appspot.com",
        messagingSenderId: "415871900749"
    };
    firebase.initializeApp(config);
</script>-->